﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flight
{ 
        public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       
        const double dt = 0.1;
        const double g = 9.81;
        const double C = 0.15;
        const double rho = 1.29;
        Object obj = new Object();

        double k;

        double t;

        private void btStart_Click(object sender, EventArgs e)
        {
            
            obj.a = (double)edAngle.Value;
            obj.v0 = (double)edSpeed.Value;
            obj.y0 = (double)edHeight.Value;
            obj.mass = (double)edWeight.Value;
            obj.S = (double)edSquare.Value;
	        obj.getY0();
            obj.getFirstVX(); obj.getFirstVY();
            k = 0.5 * C * obj.S * rho / obj.mass;

            t = 0;
          
            chart1.Series[0].Points.Clear();
            chart1.Series[0].Points.AddXY(obj.x, obj.y);

            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            t += dt;
            obj.getNextVX(k, dt);
            obj.getNextVY(k, dt, g);

            obj.getNextX(dt);
            obj.getNextY(dt);
            chart1.Series[0].Points.AddXY(obj.x, obj.y);
            if (obj.y <= 0)
            {
                timer1.Stop();
                obj.x = 0;
                obj.y = 0;
            }
        }

 
    }

    public class Object
    {
        public double mass = 0;
        public double S = 0;
        public double v0 = 0;
        public double a = 0;
        public double y0 = 0;
        public double vx = 0;
        public double vy = 0;
        public double x = 0;
        public double y = 0;

        public Object() { }

	public void getY0()
        {
            this.y = y0;
        }
        public void getFirstVX()
        {
            this.vx = v0 * Math.Cos(a * Math.PI / 180);
        }

        public void getFirstVY()
        {
            this.vy = v0 * Math.Sin(a * Math.PI / 180);
        }

        public void getNextVX(double k, double dt)
        {
            this.vx = vx - k * vx * Math.Sqrt(vx * vx + vy * vy) * dt;
        }
        public void getNextVY(double k, double dt, double g)
        {
            this.vy = vy - (g + k * vy * Math.Sqrt(vx * vx + vy * vy)) * dt;
        }

        public void getNextX(double dt)
        {
            this.x = x + vx * dt;
          
        }

        public void getNextY(double dt)
        {
            this.y = y + vy * dt;
          
        }
    }

}
