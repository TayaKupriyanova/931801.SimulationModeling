﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laba14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int N, k;
        double m, var, memp, demp;      double[] sample; int[] counter; double[] freq; double[] X;
        Random r = new Random();

        private void button1_Click(object sender, EventArgs e)
        {
            N = int.Parse((string)cbN.SelectedItem);
            m = (double)tbMean.Value;
            var = (double)tbVar.Value;
            sample = new double[N];


            k = (int)Math.Floor(Math.Log(N) / Math.Log(2) + 1);

            counter = new int[k]; for (int i = 0; i < k; i++) counter[i] = 0;
            freq = new double[k];
            X = new double[k];

            for (int i=0; i< N; i++)
            {
                sample[i] = Math.Sqrt(var)*ksi(i) + m;
            }
      
            double min, max;
            min = sample.Min(); max = sample.Max();
            double delta = (max - min) / k;

            for(int i =0; i<N; i++)
            {
                for(int j = 1; j<= k; j++)
                {
                    if (sample[i] < min + j * delta) { counter[j - 1]++; break; }
                }
            }

            for (int i = 0; i < k; i++) freq[i] = counter[i] / (double)N;

            memp = sample.Average();
            demp = 0;
            for (int i = 0; i < N; i++) demp += sample[i] * sample[i];
            demp = demp / (double)N;
            demp -= memp * memp;

            tbMemp.Text = memp.ToString("F3");
            tbDemp.Text = demp.ToString("F3");

            for(int i=0; i<k; i++)
            {
                X[i] = min + delta * (i + 1)/2;
            }

            chart1.Series[0].Points.Clear();
            for (int i = 0; i < k; i++) chart1.Series[0].Points.AddXY(X[i], freq[i]);

        }

        double ksi(int i)
        {
            int n = i + 1;
            double ksi = 0;
            for(int k =0; k<n; k++)
            {
                ksi += r.NextDouble();
            }
            ksi -= n / 2;
            ksi = ksi * (Math.Sqrt(12 / n));
            return ksi;
        }
    }
}
