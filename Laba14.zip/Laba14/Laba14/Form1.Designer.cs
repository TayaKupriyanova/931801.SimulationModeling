﻿namespace Laba14
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.tbMean = new System.Windows.Forms.NumericUpDown();
            this.tbVar = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label3 = new System.Windows.Forms.Label();
            this.cbN = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbMemp = new System.Windows.Forms.TextBox();
            this.tbDemp = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.tbMean)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbVar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // tbMean
            // 
            this.tbMean.DecimalPlaces = 2;
            this.tbMean.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.tbMean.Location = new System.Drawing.Point(92, 23);
            this.tbMean.Name = "tbMean";
            this.tbMean.Size = new System.Drawing.Size(69, 20);
            this.tbMean.TabIndex = 0;
            this.tbMean.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // tbVar
            // 
            this.tbVar.DecimalPlaces = 2;
            this.tbVar.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.tbVar.Location = new System.Drawing.Point(92, 60);
            this.tbVar.Name = "tbVar";
            this.tbVar.Size = new System.Drawing.Size(69, 20);
            this.tbVar.TabIndex = 1;
            this.tbVar.Value = new decimal(new int[] {
            25,
            0,
            0,
            131072});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Mean";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Variance";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(348, 25);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(107, 50);
            this.button1.TabIndex = 4;
            this.button1.Text = "Generate";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // chart1
            // 
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(50, 103);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(708, 322);
            this.chart1.TabIndex = 5;
            this.chart1.Text = "chart1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(181, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Sample size";
            // 
            // cbN
            // 
            this.cbN.FormatString = "N0";
            this.cbN.FormattingEnabled = true;
            this.cbN.Items.AddRange(new object[] {
            "10",
            "100",
            "1000",
            "10000"});
            this.cbN.Location = new System.Drawing.Point(250, 41);
            this.cbN.Name = "cbN";
            this.cbN.Size = new System.Drawing.Size(72, 21);
            this.cbN.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(517, 62);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Variance emp";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(517, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Mean emp";
            // 
            // tbMemp
            // 
            this.tbMemp.Location = new System.Drawing.Point(590, 23);
            this.tbMemp.Name = "tbMemp";
            this.tbMemp.ReadOnly = true;
            this.tbMemp.Size = new System.Drawing.Size(70, 20);
            this.tbMemp.TabIndex = 10;
            // 
            // tbDemp
            // 
            this.tbDemp.Location = new System.Drawing.Point(590, 60);
            this.tbDemp.Name = "tbDemp";
            this.tbDemp.ReadOnly = true;
            this.tbDemp.Size = new System.Drawing.Size(70, 20);
            this.tbDemp.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 437);
            this.Controls.Add(this.tbDemp);
            this.Controls.Add(this.tbMemp);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cbN);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbVar);
            this.Controls.Add(this.tbMean);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.tbMean)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbVar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown tbMean;
        private System.Windows.Forms.NumericUpDown tbVar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbN;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbMemp;
        private System.Windows.Forms.TextBox tbDemp;
    }
}

