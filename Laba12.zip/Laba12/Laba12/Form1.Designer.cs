﻿namespace Laba12
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Name11 = new System.Windows.Forms.TextBox();
            this.Name12 = new System.Windows.Forms.TextBox();
            this.Name13 = new System.Windows.Forms.TextBox();
            this.Name14 = new System.Windows.Forms.TextBox();
            this.Name24 = new System.Windows.Forms.TextBox();
            this.Name23 = new System.Windows.Forms.TextBox();
            this.Name22 = new System.Windows.Forms.TextBox();
            this.Name21 = new System.Windows.Forms.TextBox();
            this.Name34 = new System.Windows.Forms.TextBox();
            this.Name33 = new System.Windows.Forms.TextBox();
            this.Name32 = new System.Windows.Forms.TextBox();
            this.Name31 = new System.Windows.Forms.TextBox();
            this.Name44 = new System.Windows.Forms.TextBox();
            this.Name43 = new System.Windows.Forms.TextBox();
            this.Name42 = new System.Windows.Forms.TextBox();
            this.Name41 = new System.Windows.Forms.TextBox();
            this.l11 = new System.Windows.Forms.NumericUpDown();
            this.l12 = new System.Windows.Forms.NumericUpDown();
            this.l14 = new System.Windows.Forms.NumericUpDown();
            this.l13 = new System.Windows.Forms.NumericUpDown();
            this.l24 = new System.Windows.Forms.NumericUpDown();
            this.l23 = new System.Windows.Forms.NumericUpDown();
            this.l22 = new System.Windows.Forms.NumericUpDown();
            this.l21 = new System.Windows.Forms.NumericUpDown();
            this.l34 = new System.Windows.Forms.NumericUpDown();
            this.l33 = new System.Windows.Forms.NumericUpDown();
            this.l32 = new System.Windows.Forms.NumericUpDown();
            this.l31 = new System.Windows.Forms.NumericUpDown();
            this.l44 = new System.Windows.Forms.NumericUpDown();
            this.l43 = new System.Windows.Forms.NumericUpDown();
            this.l42 = new System.Windows.Forms.NumericUpDown();
            this.l41 = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.result = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.l11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.l12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.l14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.l13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.l24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.l23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.l22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.l21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.l34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.l33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.l32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.l31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.l44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.l43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.l42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.l41)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(668, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(120, 42);
            this.button1.TabIndex = 0;
            this.button1.Text = "Generate";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(148, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Group 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(148, 240);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Group 3";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(441, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Group 2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(441, 240);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Group 4";
            // 
            // Name11
            // 
            this.Name11.Location = new System.Drawing.Point(55, 47);
            this.Name11.Name = "Name11";
            this.Name11.Size = new System.Drawing.Size(98, 20);
            this.Name11.TabIndex = 5;
            // 
            // Name12
            // 
            this.Name12.Location = new System.Drawing.Point(55, 82);
            this.Name12.Name = "Name12";
            this.Name12.Size = new System.Drawing.Size(98, 20);
            this.Name12.TabIndex = 6;
            // 
            // Name13
            // 
            this.Name13.Location = new System.Drawing.Point(55, 117);
            this.Name13.Name = "Name13";
            this.Name13.Size = new System.Drawing.Size(98, 20);
            this.Name13.TabIndex = 7;
            // 
            // Name14
            // 
            this.Name14.Location = new System.Drawing.Point(55, 153);
            this.Name14.Name = "Name14";
            this.Name14.Size = new System.Drawing.Size(98, 20);
            this.Name14.TabIndex = 8;
            // 
            // Name24
            // 
            this.Name24.Location = new System.Drawing.Point(356, 153);
            this.Name24.Name = "Name24";
            this.Name24.Size = new System.Drawing.Size(98, 20);
            this.Name24.TabIndex = 12;
            // 
            // Name23
            // 
            this.Name23.Location = new System.Drawing.Point(356, 117);
            this.Name23.Name = "Name23";
            this.Name23.Size = new System.Drawing.Size(98, 20);
            this.Name23.TabIndex = 11;
            // 
            // Name22
            // 
            this.Name22.Location = new System.Drawing.Point(356, 82);
            this.Name22.Name = "Name22";
            this.Name22.Size = new System.Drawing.Size(98, 20);
            this.Name22.TabIndex = 10;
            // 
            // Name21
            // 
            this.Name21.Location = new System.Drawing.Point(356, 47);
            this.Name21.Name = "Name21";
            this.Name21.Size = new System.Drawing.Size(98, 20);
            this.Name21.TabIndex = 9;
            // 
            // Name34
            // 
            this.Name34.Location = new System.Drawing.Point(55, 390);
            this.Name34.Name = "Name34";
            this.Name34.Size = new System.Drawing.Size(98, 20);
            this.Name34.TabIndex = 16;
            // 
            // Name33
            // 
            this.Name33.Location = new System.Drawing.Point(55, 354);
            this.Name33.Name = "Name33";
            this.Name33.Size = new System.Drawing.Size(98, 20);
            this.Name33.TabIndex = 15;
            // 
            // Name32
            // 
            this.Name32.Location = new System.Drawing.Point(55, 319);
            this.Name32.Name = "Name32";
            this.Name32.Size = new System.Drawing.Size(98, 20);
            this.Name32.TabIndex = 14;
            // 
            // Name31
            // 
            this.Name31.Location = new System.Drawing.Point(55, 284);
            this.Name31.Name = "Name31";
            this.Name31.Size = new System.Drawing.Size(98, 20);
            this.Name31.TabIndex = 13;
            // 
            // Name44
            // 
            this.Name44.Location = new System.Drawing.Point(356, 390);
            this.Name44.Name = "Name44";
            this.Name44.Size = new System.Drawing.Size(98, 20);
            this.Name44.TabIndex = 20;
            // 
            // Name43
            // 
            this.Name43.Location = new System.Drawing.Point(356, 354);
            this.Name43.Name = "Name43";
            this.Name43.Size = new System.Drawing.Size(98, 20);
            this.Name43.TabIndex = 19;
            // 
            // Name42
            // 
            this.Name42.Location = new System.Drawing.Point(356, 319);
            this.Name42.Name = "Name42";
            this.Name42.Size = new System.Drawing.Size(98, 20);
            this.Name42.TabIndex = 18;
            // 
            // Name41
            // 
            this.Name41.Location = new System.Drawing.Point(356, 284);
            this.Name41.Name = "Name41";
            this.Name41.Size = new System.Drawing.Size(98, 20);
            this.Name41.TabIndex = 17;
            // 
            // l11
            // 
            this.l11.Location = new System.Drawing.Point(213, 47);
            this.l11.Name = "l11";
            this.l11.Size = new System.Drawing.Size(52, 20);
            this.l11.TabIndex = 21;
            this.l11.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // l12
            // 
            this.l12.Location = new System.Drawing.Point(213, 82);
            this.l12.Name = "l12";
            this.l12.Size = new System.Drawing.Size(52, 20);
            this.l12.TabIndex = 22;
            this.l12.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // l14
            // 
            this.l14.Location = new System.Drawing.Point(213, 153);
            this.l14.Name = "l14";
            this.l14.Size = new System.Drawing.Size(52, 20);
            this.l14.TabIndex = 24;
            this.l14.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // l13
            // 
            this.l13.Location = new System.Drawing.Point(213, 118);
            this.l13.Name = "l13";
            this.l13.Size = new System.Drawing.Size(52, 20);
            this.l13.TabIndex = 23;
            this.l13.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // l24
            // 
            this.l24.Location = new System.Drawing.Point(523, 153);
            this.l24.Name = "l24";
            this.l24.Size = new System.Drawing.Size(52, 20);
            this.l24.TabIndex = 28;
            this.l24.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // l23
            // 
            this.l23.Location = new System.Drawing.Point(523, 118);
            this.l23.Name = "l23";
            this.l23.Size = new System.Drawing.Size(52, 20);
            this.l23.TabIndex = 27;
            this.l23.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // l22
            // 
            this.l22.Location = new System.Drawing.Point(523, 82);
            this.l22.Name = "l22";
            this.l22.Size = new System.Drawing.Size(52, 20);
            this.l22.TabIndex = 26;
            this.l22.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // l21
            // 
            this.l21.Location = new System.Drawing.Point(523, 47);
            this.l21.Name = "l21";
            this.l21.Size = new System.Drawing.Size(52, 20);
            this.l21.TabIndex = 25;
            this.l21.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // l34
            // 
            this.l34.Location = new System.Drawing.Point(213, 390);
            this.l34.Name = "l34";
            this.l34.Size = new System.Drawing.Size(52, 20);
            this.l34.TabIndex = 32;
            this.l34.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // l33
            // 
            this.l33.Location = new System.Drawing.Point(213, 355);
            this.l33.Name = "l33";
            this.l33.Size = new System.Drawing.Size(52, 20);
            this.l33.TabIndex = 31;
            this.l33.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // l32
            // 
            this.l32.Location = new System.Drawing.Point(213, 319);
            this.l32.Name = "l32";
            this.l32.Size = new System.Drawing.Size(52, 20);
            this.l32.TabIndex = 30;
            this.l32.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // l31
            // 
            this.l31.Location = new System.Drawing.Point(213, 284);
            this.l31.Name = "l31";
            this.l31.Size = new System.Drawing.Size(52, 20);
            this.l31.TabIndex = 29;
            this.l31.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // l44
            // 
            this.l44.Location = new System.Drawing.Point(523, 390);
            this.l44.Name = "l44";
            this.l44.Size = new System.Drawing.Size(52, 20);
            this.l44.TabIndex = 36;
            this.l44.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // l43
            // 
            this.l43.Location = new System.Drawing.Point(523, 355);
            this.l43.Name = "l43";
            this.l43.Size = new System.Drawing.Size(52, 20);
            this.l43.TabIndex = 35;
            // 
            // l42
            // 
            this.l42.Location = new System.Drawing.Point(523, 319);
            this.l42.Name = "l42";
            this.l42.Size = new System.Drawing.Size(52, 20);
            this.l42.TabIndex = 34;
            this.l42.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // l41
            // 
            this.l41.Location = new System.Drawing.Point(523, 284);
            this.l41.Name = "l41";
            this.l41.Size = new System.Drawing.Size(52, 20);
            this.l41.TabIndex = 33;
            this.l41.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 47);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 37;
            this.label5.Text = "Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 85);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 38;
            this.label6.Text = "Name";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 156);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 40;
            this.label7.Text = "Name";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 118);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 39;
            this.label8.Text = "Name";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(315, 155);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 13);
            this.label9.TabIndex = 44;
            this.label9.Text = "Name";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(315, 120);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 13);
            this.label10.TabIndex = 43;
            this.label10.Text = "Name";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(315, 85);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 13);
            this.label11.TabIndex = 42;
            this.label11.Text = "Name";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(315, 50);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 13);
            this.label12.TabIndex = 41;
            this.label12.Text = "Name";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(14, 392);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 13);
            this.label13.TabIndex = 48;
            this.label13.Text = "Name";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(14, 357);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 13);
            this.label14.TabIndex = 47;
            this.label14.Text = "Name";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(14, 322);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(35, 13);
            this.label15.TabIndex = 46;
            this.label15.Text = "Name";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(14, 287);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 13);
            this.label16.TabIndex = 45;
            this.label16.Text = "Name";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(315, 392);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 13);
            this.label17.TabIndex = 52;
            this.label17.Text = "Name";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(315, 357);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(35, 13);
            this.label18.TabIndex = 51;
            this.label18.Text = "Name";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(315, 322);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(35, 13);
            this.label19.TabIndex = 50;
            this.label19.Text = "Name";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(315, 287);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(35, 13);
            this.label20.TabIndex = 49;
            this.label20.Text = "Name";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(175, 50);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(32, 13);
            this.label21.TabIndex = 53;
            this.label21.Text = "goals";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(175, 85);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(32, 13);
            this.label22.TabIndex = 54;
            this.label22.Text = "goals";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(175, 120);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(32, 13);
            this.label23.TabIndex = 55;
            this.label23.Text = "goals";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(175, 156);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(32, 13);
            this.label24.TabIndex = 56;
            this.label24.Text = "goals";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(485, 156);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(32, 13);
            this.label25.TabIndex = 60;
            this.label25.Text = "goals";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(485, 120);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(32, 13);
            this.label26.TabIndex = 59;
            this.label26.Text = "goals";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(485, 85);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(32, 13);
            this.label27.TabIndex = 58;
            this.label27.Text = "goals";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(485, 50);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(32, 13);
            this.label28.TabIndex = 57;
            this.label28.Text = "goals";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(175, 393);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(32, 13);
            this.label29.TabIndex = 64;
            this.label29.Text = "goals";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(175, 357);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(32, 13);
            this.label30.TabIndex = 63;
            this.label30.Text = "goals";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(175, 322);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(32, 13);
            this.label31.TabIndex = 62;
            this.label31.Text = "goals";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(175, 287);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(32, 13);
            this.label32.TabIndex = 61;
            this.label32.Text = "goals";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(485, 393);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(32, 13);
            this.label33.TabIndex = 68;
            this.label33.Text = "goals";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(485, 357);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(32, 13);
            this.label34.TabIndex = 67;
            this.label34.Text = "goals";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(485, 322);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(32, 13);
            this.label35.TabIndex = 66;
            this.label35.Text = "goals";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(485, 287);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(32, 13);
            this.label36.TabIndex = 65;
            this.label36.Text = "goals";
            // 
            // result
            // 
            this.result.Location = new System.Drawing.Point(639, 75);
            this.result.Multiline = true;
            this.result.Name = "result";
            this.result.ReadOnly = true;
            this.result.Size = new System.Drawing.Size(337, 363);
            this.result.TabIndex = 69;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(987, 450);
            this.Controls.Add(this.result);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.l44);
            this.Controls.Add(this.l43);
            this.Controls.Add(this.l42);
            this.Controls.Add(this.l41);
            this.Controls.Add(this.l34);
            this.Controls.Add(this.l33);
            this.Controls.Add(this.l32);
            this.Controls.Add(this.l31);
            this.Controls.Add(this.l24);
            this.Controls.Add(this.l23);
            this.Controls.Add(this.l22);
            this.Controls.Add(this.l21);
            this.Controls.Add(this.l14);
            this.Controls.Add(this.l13);
            this.Controls.Add(this.l12);
            this.Controls.Add(this.l11);
            this.Controls.Add(this.Name44);
            this.Controls.Add(this.Name43);
            this.Controls.Add(this.Name42);
            this.Controls.Add(this.Name41);
            this.Controls.Add(this.Name34);
            this.Controls.Add(this.Name33);
            this.Controls.Add(this.Name32);
            this.Controls.Add(this.Name31);
            this.Controls.Add(this.Name24);
            this.Controls.Add(this.Name23);
            this.Controls.Add(this.Name22);
            this.Controls.Add(this.Name21);
            this.Controls.Add(this.Name14);
            this.Controls.Add(this.Name13);
            this.Controls.Add(this.Name12);
            this.Controls.Add(this.Name11);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.l11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.l12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.l14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.l13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.l24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.l23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.l22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.l21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.l34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.l33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.l32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.l31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.l44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.l43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.l42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.l41)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Name11;
        private System.Windows.Forms.TextBox Name12;
        private System.Windows.Forms.TextBox Name13;
        private System.Windows.Forms.TextBox Name14;
        private System.Windows.Forms.TextBox Name24;
        private System.Windows.Forms.TextBox Name23;
        private System.Windows.Forms.TextBox Name22;
        private System.Windows.Forms.TextBox Name21;
        private System.Windows.Forms.TextBox Name34;
        private System.Windows.Forms.TextBox Name33;
        private System.Windows.Forms.TextBox Name32;
        private System.Windows.Forms.TextBox Name31;
        private System.Windows.Forms.TextBox Name44;
        private System.Windows.Forms.TextBox Name43;
        private System.Windows.Forms.TextBox Name42;
        private System.Windows.Forms.TextBox Name41;
        private System.Windows.Forms.NumericUpDown l11;
        private System.Windows.Forms.NumericUpDown l12;
        private System.Windows.Forms.NumericUpDown l14;
        private System.Windows.Forms.NumericUpDown l13;
        private System.Windows.Forms.NumericUpDown l24;
        private System.Windows.Forms.NumericUpDown l23;
        private System.Windows.Forms.NumericUpDown l22;
        private System.Windows.Forms.NumericUpDown l21;
        private System.Windows.Forms.NumericUpDown l34;
        private System.Windows.Forms.NumericUpDown l33;
        private System.Windows.Forms.NumericUpDown l32;
        private System.Windows.Forms.NumericUpDown l31;
        private System.Windows.Forms.NumericUpDown l44;
        private System.Windows.Forms.NumericUpDown l43;
        private System.Windows.Forms.NumericUpDown l42;
        private System.Windows.Forms.NumericUpDown l41;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox result;
    }
}

