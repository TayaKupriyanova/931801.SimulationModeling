﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laba12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        const int n = 4;
        const int n1 = 8;
        Random r = new Random();
        int r2, r1;
        int j;

        private void button1_Click(object sender, EventArgs e)
        {
            result.Clear();


            Team[] group1; Team[] group2; Team[] group3; Team[] group4;
            string[] names1 = { Name11.Text, Name12.Text, Name13.Text, Name14.Text };
            string[] names2 = { Name21.Text, Name22.Text, Name23.Text, Name24.Text };
            string[] names3 = { Name31.Text, Name32.Text, Name33.Text, Name34.Text };
            string[] names4 = { Name41.Text, Name42.Text, Name43.Text, Name44.Text };

            int[] ls1 = { (int)l11.Value, (int)l12.Value, (int)l13.Value, (int)l14.Value };
            int[] ls2 = { (int)l21.Value, (int)l22.Value, (int)l23.Value, (int)l24.Value };
            int[] ls3 = { (int)l31.Value, (int)l32.Value, (int)l33.Value, (int)l34.Value };
            int[] ls4 = { (int)l41.Value, (int)l42.Value, (int)l43.Value, (int)l44.Value };


            group1 = new Team[n]; group2 = new Team[n]; group3 = new Team[n]; group4 = new Team[n];
            for( int i =0; i<n; i++)
            {
                group1[i] =new Team(names1[i], ls1[i]);
                group2[i] = new Team(names2[i], ls2[i]);
                group3[i] = new Team(names3[i], ls3[i]);
                group4[i] = new Team(names4[i], ls4[i]);
            }

            // групповой этап

            for(int i =0; i<n-1; i++)
            {
                for(int j = i+1; j<n; j++)
                {
                    group1[i].setScore(group1[i].poisson()); group1[j].setScore(group1[j].poisson()); // сгенерировали кол-во голов
                    group2[i].setScore(group2[i].poisson()); group2[j].setScore(group2[j].poisson());
                    group3[i].setScore(group3[i].poisson()); group3[j].setScore(group3[j].poisson());
                    group4[i].setScore(group4[i].poisson()); group4[j].setScore(group4[j].poisson());
                }
            }

            int max1 = 100, max2 = 100, max3 = 100, max4 = 100;
            int imax11 = 0, imax1 = 0,  imax22 = 0, imax2 = 0, imax33 = 0, imax3 = 0, imax44 = 0, imax4 = 0;

            for (int i =0; i<n; i++)
            {
                if(group1[i].score <= max1) { max1 = group1[i].score; imax1 = i; }

                if (group2[i].score <= max2) { max2 = group2[i].score; imax2 = i; }

                if (group3[i].score <= max3) { max3 = group3[i].score; imax3 = i; }

                if (group1[i].score <= max4) { max4 = group4[i].score; imax4 = i; }
            }

            for (int i = 0; i < n; i++)
            {
                if (group1[i].score <= max1 && imax1 != i) { max1 = group1[i].score; imax11 = i; }

                if (group2[i].score <= max2 && imax2 != i) { max2 = group2[i].score; imax22 = i; }

                if (group3[i].score <= max3 && imax3 != i) { max3 = group3[i].score; imax33 = i; }

                if (group1[i].score <= max4 && imax4 != i) { max4 = group4[i].score; imax44 = i; }
            }

            // вывести победителей, прошедших в плей офф этап
            result.AppendText("Teams-winners from 1st group\n");
            result.AppendText(group1[imax1].name + ",\t" + group1[imax11].name + "\n");

            result.AppendText("Teams-winners from 2nd group\n");
            result.AppendText(group2[imax2].name + ",\t" + group2[imax22].name + "\n");

            result.AppendText("Teams-winners from 3rd group\n");
            result.AppendText(group3[imax3].name + ",\t" + group3[imax33].name + "\n");

            result.AppendText("Teams-winners from 4th group\n");
            result.AppendText(group4[imax4].name + ",\t" + group4[imax44].name + "\n");

            // 1/4

            Team[] quarter = { group1[imax1], group2[imax2], group3[imax3], group4[imax4], group1[imax11], group2[imax22],group3[imax33], group4[imax44] };

            for(int i=0; i<n1-1; i += 2)
            {
                r1 = quarter[i].poisson(); r2 = quarter[i + 1].poisson();
               if (r1 > r2) { quarter[i].setWin(); }
               if (r1 < r2) { quarter[i+1].setWin(); }
               if(r1 == r2) { Math.DivRem(r.Next(), 2, out j); quarter[i+j].setWin(); }  
            }

            // вывести победителй


            // 1/2
            result.AppendText("Winners\n");
            Team[] semifinal;
            semifinal = new Team[n];
             for( int i=0; i<n; i++)
             {
                for (int j = 0; j < n1; j++)
                    if (quarter[j].win) { semifinal[i] = quarter[j]; break; }
                semifinal[i].setLose();
                result.AppendText(semifinal[i].name + "\t");
             }

             for (int i = 0; i<n; i+=2)
             {
                r1 = semifinal[i].poisson(); r2 = semifinal[i + 1].poisson();
                if (r1 > r2) { semifinal[i].setWin(); }
                if (r1 < r2) { semifinal[i + 1].setWin(); }
                if (r1 == r2) { Math.DivRem(r.Next(), 2, out j); semifinal[i + j].setWin(); }
             }

            // вывести победителй
            result.AppendText("\n\n\n Winners\n");
            // финал

            Team[] final;
            final = new Team[2];
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < n; j++)
                    if (semifinal[j].win) { final[i] = semifinal[j]; break; }
                final[i].setLose();
                result.AppendText(final[i].name + "\t");
            }

            r1 = final[0].poisson(); r2 = final[1].poisson();
            if (r1 > r2) {final[0].setWin(); }
            if (r1 < r2) { final[1].setWin(); }
            if (r1 == r2) { Math.DivRem(r.Next(), 2, out j); final[j].setWin(); }

            Team winner; winner = new Team(null, 0);
            for (int i = 0; i<2; i++)
            {
                if (final[i].win) { winner = new Team(final[i].name, final[i].l); break; }
            }

            // вывести победителя
            result.AppendText("\n\n\n The ultimate winner is " + winner.name);


        }
    }

    class Team
    {
        public string name;
        public int score;
        public bool win;
        public int l;

        public Team(string Name, int el)
        {
            name = Name;
            score = 0;
            win = false;
            l = el;
        }

        public int poisson()
        {
            Random rnd = new Random();
            double sum = 0; int i;
            for (i = -1; sum >= -l; i++) sum += Math.Log(rnd.NextDouble());
            return i;
        }

        public void setWin()
        {
            win = true;
        }

        public void setLose()
        {
            win = false;
        }

        public void setScore(int i)
        {
            score += i;
        }
    }

}
